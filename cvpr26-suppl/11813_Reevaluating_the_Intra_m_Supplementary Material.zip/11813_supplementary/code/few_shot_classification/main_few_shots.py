import os
import pickle
import random
import argparse
from tqdm import tqdm

import torch
import torch.nn.functional as F
import torchvision.transforms as transforms

from datasets.imagenet import ImageNet
from datasets import build_dataset
from datasets.utils import build_data_loader
import clip
from utils import *

import sys
# Add the parent directory to Python path to import `projection`
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import projection

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def get_arguments():
    parser = argparse.ArgumentParser()
    # parser.add_argument('--config', dest='config', help='settings of Tip-Adapter in yaml format')
    parser.add_argument('--method', choices=['project', 'prototype', 'gda'], default='gda')
    parser.add_argument('--use_text', action='store_true')
    parser.add_argument('--root_path', default='datasets')
    parser.add_argument('--dataset', choices=[
        'stanford_cars', 'oxford_pets', 'oxford_flowers', 'fgvc_aircraft',
        'dtd', 'eurosat', 'food-101', 'caltech101', 'ucf101', 'sun397', 'imagenet'
    ], required=True)
    parser.add_argument('--shots', default=16)
    parser.add_argument('--backbone', choices=['RN50', 'ViT-B/16', 'ViT-B/32', 'ViT-L/14',
                                               'siglip-ViT-B-16', 'siglip2-ViT-B-16',
                                               'dinov2_vitb14','dinov3_vitl16'], default='RN50')
    parser.add_argument('--subsample_classes', default='all')
    parser.add_argument('--augment_epoch', type=int, default=10)
    args = parser.parse_args()
    return args

def fwd_images(cfg, train_loader_cache, clip_model, cached=True):
    vecs = []
    labels = []
    if cached:
        #for i in range(cfg["augment_epoch"]):
        embs, labs = load_preextracted_features(all_feats, all_img_pths, train_loader_cache, device)
        vecs.append(embs.float().to(device))
        labels.append(labs.to(device))
    else:
        with torch.no_grad():
            for i in range(cfg["augment_epoch"]):
                for batch in tqdm(train_loader_cache):
                    image, target = batch['img'].to(device), batch['label'].to(device)
                    image_features = clip_model.encode_image(image)
                    image_features = image_features / image_features.norm(dim=-1, keepdim=True)
                    vecs.append(image_features)
                    labels.append(target)
            vecs = torch.cat(vecs)
            labels = torch.cat(labels)

    return torch.cat(vecs),torch.cat(labels)


def best_alpha_grid_search(fs_logits, clip_weights):
    # Grid search for hyper-parameter alpha (as in iclr24 gda)
    best_val_acc = 0
    best_alpha = 0.1
    for alpha in [0.0001, 0.001, 0.01, 0.1, 1.0, 10.0, 100.0]:
        val_logits = 100. * val_features.float() @ clip_weights.float() + alpha * fs_logits

        acc = cls_acc(val_logits, val_labels)
        if acc > best_val_acc:
            best_val_acc = acc
            best_alpha = alpha
    return best_alpha

def calc_acc_from_sims(sims):
    test_logits = sims / 0.01
    notune_acc = cls_acc(test_logits, test_labels)
    print("Nonetune acc:", notune_acc)
    return notune_acc

def prototype_classify(fewshot_features, labels, clip_weights=None):
    class_protos = torch.stack([fewshot_features[labels==i].mean(dim=0) for i in labels.unique()]) # shape (n,d)
    class_protos = F.normalize(class_protos, dim=-1)

    fs_sims = test_features.float() @ class_protos.T # (N,n)
    if clip_weights is not None:
        val_sims = val_features.float() @ class_protos.T
        best_alpha = best_alpha_grid_search(val_sims, clip_weights)
        txt_sims = test_features.float() @ clip_weights.float()
        fs_sims = 100. * txt_sims + best_alpha * fs_sims
    return calc_acc_from_sims(fs_sims)

def run_zero_shot(cfg, train_loader_cache, clip_weights, clip_model):
    sims = test_features.float() @ clip_weights.float()
    return calc_acc_from_sims(sims)

def run_prototype_classify(cfg, train_loader_cache, clip_weights, clip_model):
    image_features, labels = fwd_images(cfg, train_loader_cache, clip_model)
    return prototype_classify(image_features, labels, clip_weights) # or w/o clip_weights

def run_projection(cfg, train_loader_cache, clip_weights, clip_model):
    image_features, labels = fwd_images(cfg, train_loader_cache, clip_model)

#    clip_model_names = {'RN50':'RN50', 'ViT-B/16':'ViT-B/16' ,'ViT-B/16'}
    dataset_name = cfg['dataset'].replace('-','')
    txt_feats = projection.fwd_imagenet_texts(clip_model, tokenize_fn=clip.tokenize,
                                              cache_path=os.path.join('data','text_features',
                                                                      cfg['backbone'], dataset_name))
    pca = projection.fit_pca(txt_feats)
    image_features = projection.transform_pca(pca, image_features)
    return prototype_classify(image_features, labels, clip_weights)

def run_gda_iclr24(cfg, train_loader_cache, clip_weights, clip_model):
    vecs, labels = fwd_images(cfg, train_loader_cache, clip_model)
    n_class = len(labels.unique())
    # Parameter Estimation.

    # normal distribution
    mus = torch.cat([vecs[labels == i].mean(dim=0, keepdim=True) for i in range(n_class)])

    # KS Estimator.
    center_vecs = torch.cat([vecs[labels == i] - mus[i].unsqueeze(0) for i in range(n_class)])
    cov_inv = center_vecs.shape[1] * torch.linalg.pinv((center_vecs.shape[0] - 1) * center_vecs.T.cov() + center_vecs.T.cov().trace() * torch.eye(center_vecs.shape[1]).cuda())

    ps = torch.ones(n_class).cuda() * 1. / n_class

    W = torch.einsum('nd, dc -> cn', mus, cov_inv)
    b = ps.log() - torch.einsum('nd, dc, nc -> n', mus, cov_inv, mus) / 2

    if cfg['use_text']:
        # Evaluate
        val_logits = val_features.float() @ W + b
        alpha = best_alpha_grid_search(val_logits, clip_weights)
        test_logits = 100. * test_features.float() @ clip_weights.float() + alpha * (test_features.float() @ W + b)
    else:
        test_logits = 100. * (test_features.float() @ W + b)
    notune_acc = cls_acc(test_logits, test_labels)
    print("Nonetune acc:", notune_acc)
    return notune_acc


def main():
    args = get_arguments()
    
    cfg = args.__dict__
    
    # Load cfg for conditional prompt.
    print("\nRunning configs.")
    print(cfg, "\n")

    bb=cfg['backbone'].lower()
    if not 'siglip' in bb and not 'SLIP' in bb and not 'dino' in bb:
        clip_model, preprocess = clip.load(cfg['backbone'])
        clip_model.eval()
        for p in clip_model.parameters():
            p.requires_grad = False
    else: clip_model = None

    # load pre-extracted embeddings
    feat_dir = f'data/image_features/{cfg["dataset"]}'
    global all_feats, all_img_pths
    all_feats = torch.load(f'{feat_dir}/{cfg["backbone"].replace("/", "_")}.pt')
    with open(f'{feat_dir}/image_names.pkl', 'rb') as f:
        all_img_pths = pickle.load(f)
        
    notune_accs = {"1": [], "2": [], "3": []}
    
    for seed in [1, 2, 3]:
        cfg["seed"] = seed
        random.seed(seed*100)
        torch.manual_seed(seed) 
        
        for shots in [1, 2, 4, 8, 16]:
            cfg["shots"] = shots
        
            print("Preparing dataset.")
            #global train_loader_F
            global test_features, test_labels
            global val_features, val_labels
            if cfg['dataset'] != "imagenet":
                dataset = build_dataset(cfg, cfg['dataset'].replace('-', ''), cfg['root_path'], cfg['shots'])

                # cached: don't load actual image, just path
                train_loader_cache = build_data_loader(data_source=dataset.train_x, batch_size=256, tfm='cached', is_train=True, shuffle=False)
                #train_loader_F = build_data_loader(data_source=dataset.train_x, batch_size=256, tfm=train_transform, is_train=True, shuffle=True)

                test_loader = build_data_loader(data_source=dataset.test, batch_size=256, is_train=False, tfm='cached', shuffle=False)

                val_loader = build_data_loader(data_source=dataset.val, batch_size=256, is_train=False, tfm='cached', shuffle=False)

                test_features, test_labels = load_preextracted_features(all_feats, all_img_pths, test_loader, device)
                val_features, val_labels = load_preextracted_features(all_feats, all_img_pths, val_loader, device)

            else:
                dataset = ImageNet(cfg, cfg['root_path'], cfg['shots'], preprocess, cached=True)
                # train
                #train_loader_F = torch.utils.data.DataLoader(dataset.train, batch_size=256, num_workers=8, shuffle=True)
                train_loader_cache = torch.utils.data.DataLoader(dataset.train, batch_size=256, num_workers=8, shuffle=False)

                test_loader = torch.utils.data.DataLoader(dataset.test, batch_size=64, num_workers=8, shuffle=False)

                test_features, test_labels = load_preextracted_features(all_feats, all_img_pths, test_loader)
                val_features, val_labels = test_features, test_labels


            clip_weights = clip_classifier(dataset.classnames, dataset.template, clip_model.float()).to(device) if args.use_text else None

            cfg['classnames'] = dataset.classnames
            method = run_projection if args.method == 'project' else run_prototype_classify if args.method == 'prototype' else run_gda_iclr24
            notune_acc = method(cfg, train_loader_cache, clip_weights, clip_model)
            notune_accs[str(cfg["seed"])].append(notune_acc)
    print({k:v for k,v in cfg.items() if k!='classnames'})
    print("Evaluate on seed [1, 2, 3]")
    print("Evaluate on shots [1, 2, 4, 8, 16]")
    print("No tuning:")
    notune = []
    for seed in ["1", "2", "3"]:
        print("seed %s" % seed, notune_accs[str(seed)])
        notune.append(notune_accs[seed])
    notune = torch.tensor(notune)
    print("Average: ", notune.mean(dim=0))
    
if __name__ == '__main__':
    main()